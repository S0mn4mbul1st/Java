package lab;

import java.util.*;

public class MergeSort {
	
	public static class Sorter implements Runnable {
		
		private int[] a;
		
		private int thCounter;
		
		public Sorter(int[] a, int thCounter) {
	
			this.a = a;
			
			this.thCounter = thCounter;
		}
		
		public void run() {
			
			MergeSort.parallelMergeSort(a, thCounter);
		}
	}
	
	private static final Random RAND = new Random(42); 
														
	public static void main(String[] args) throws Throwable {
	
		int len = 1000 , times = 16 ; 

		for (int i = 1; i <= times; i++) {
		
			int[] a = createRandomArray(len);
			
			System.out.println("\nCurrent times is " + i + "\n");		

			long startTime1 = System.currentTimeMillis();

			parallelMergeSort(a);
			
			long endTime1 = System.currentTimeMillis();

			if ( !isSorted ( a ) ) {

				throw new RuntimeException("not sorted: " + Arrays.toString(a));
			}

			System.out.printf("%10d elements : %6dms \n", len, endTime1 - startTime1);
		
			len *= 2;
			
		}
	}

	public static void parallelMergeSort(int[] a) {
	
		int cores = 8;
		
		parallelMergeSort(a, cores);
	}

	public static void parallelMergeSort(int[] a, int thCounter) {

		if (thCounter <= 1) 
		
			mergeSort(a);
		
		else if (a.length  >= 2) {
		
			int[] left = Arrays.copyOfRange(a, 0, a.length  / 2);
			
			int[] right = Arrays.copyOfRange(a, a.length  / 2, a.length );

			Thread lThread = new Thread(new Sorter(left, thCounter / 2));
			
			Thread rThread = new Thread(new Sorter(right, thCounter / 2));
			
			lThread.start();
			
			rThread.start();

			try {
			
				lThread.join();
				
				rThread.join();
			}
			
			catch (InterruptedException ie) {
			}

			merge(left, right, a);
		}
	}

		public static void merge(int[] left, int[] right, int[] a) {
	
			int i1 = 0 , i2 = 0;
	
		for (int i = 0; i < a.length ; i++) 
	
			if ( i2 >= right.length  || ( i1 < left.length  && left[i1] < right[i2] ) ) {
			
				a[i] = left[i1];
				
				i1 ++;
			} 
			
			else {
				
				a[i] = right[i2];
			
				i2++;
			}
		
	}
	
		public static void mergeSort(int[] a) {
	
			if (a.length  >= 2) {
		
				int[] left = Arrays.copyOfRange(a, 0, a.length  / 2);
			
				int[] right = Arrays.copyOfRange(a, a.length  / 2, a.length );

				mergeSort(left);

				mergeSort(right);

				merge(left, right, a);
			}
		}
	

	public static final void swap(int[] a, int i, int j) {
	
		if (i != j) {
		
			int temp = a[i];
			
			a[i] = a[j];
			
			a[j] = temp;
		}
	}

	public static void shuffle(int[] a) {
	
		for (int i = 0; i < a.length ; i++) {
		
			int randomIndex = (int) (Math.random() * a.length  - i);
			
			swap(a, i, i + randomIndex);
		}
	}

	public static boolean isSorted(int[] a) {
	
		for (int i = 0; i < a.length  - 1; i ++ ) 
		
			if ( a[i] > a[i + 1] ) 
			
				return false;
			
		return true;
	}

	public static int[] createRandomArray(int len) {
		
		int[] a = new int[len];
		
		for (int i = 0; i < a.length ; i ++ ) 
		
			a[i] = RAND.nextInt( 1000000 );
		
		return a;
	}
}